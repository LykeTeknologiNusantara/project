import React from "react";
import Demos from "./demos/demos";

const Home = () => {
  return (
    <>
      <Demos />
    </>
  );
};

export default Home;
